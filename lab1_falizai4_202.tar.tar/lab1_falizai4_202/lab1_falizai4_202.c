/*
Faryal Alizai G01364057
CS 262, Lab section 202
Lab1: printing hello world with my name
*/
#include <stdio.h>

int main() {
	char name[100] = "Faryal Alizai/*";
	printf("Hello World!\nMy name is %s\n", name);
	return 0;
}

